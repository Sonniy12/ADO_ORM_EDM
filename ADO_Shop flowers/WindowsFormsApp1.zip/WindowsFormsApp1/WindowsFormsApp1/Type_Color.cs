﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    enum Type_fl
        {
        Розы,
        Тюльпаны,
        Хризантемы,
        Лилии,
        Пионы,
        Ирисы,
        Гвоздики


    }
    enum Color_fl
    {
        Красные,
        Белые,
        Розовые,
        Желтые,
        Бордо

        
    }
}
